/* ═══════════════════════════════════════════════════════════════
   Castle Capitalist — Main Game Component
   An idle/incremental dungeon game inspired by Adventure Capitalist.
   
   Web prototype (React). Architecture designed to port cleanly to
   React Native + Expo for iOS/Android release.
   ═══════════════════════════════════════════════════════════════ */

import { useState, useEffect, useRef, useCallback } from "react";
import { VENTURE_ICONS, GoldCoin, SoulGem } from "./Icons";
import {
  VENTURES, MILESTONES, COMPANION_COSTS, COMPANION_NAMES, COMPANION_DESCS,
  PRESTIGE_BASE, PRESTIGE_GEM_BONUS, OFFLINE_EFFICIENCY, SAVE_KEY,
} from "../config/gameConfig";
import {
  getMilestoneMultiplier, getUnitCost, getBulkCost, getRevenue,
  getMaxBuyable, calcPrestigeGems, getNextMilestone, formatNumber, formatTime,
} from "../utils/gameMath";

// ── Initial State ──
const createInitialState = () =>
  VENTURES.map((_, i) => ({
    owned: i === 0 ? 1 : 0,
    hasCompanion: false,
    progress: 0,
    running: false,
  }));

export default function CastleCapitalist() {
  const [gold, setGold] = useState(4);
  const [ventures, setVentures] = useState(createInitialState);
  const [prestigeGems, setPrestigeGems] = useState(0);
  const [totalGems, setTotalGems] = useState(0);
  const [buyQty, setBuyQty] = useState(1);
  const [tab, setTab] = useState("ventures");
  const [lifetimeGold, setLifetimeGold] = useState(0);

  const lastTick = useRef(Date.now());
  const animRef = useRef(null);
  const goldRef = useRef(gold);
  const venturesRef = useRef(ventures);
  const gemsRef = useRef(prestigeGems);

  goldRef.current = gold;
  venturesRef.current = ventures;
  gemsRef.current = prestigeGems;

  const prestigeMultiplier = 1 + totalGems * PRESTIGE_GEM_BONUS;

  // ═══ SAVE / LOAD ═══
  useEffect(() => {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return;
      const save = JSON.parse(raw);

      if (save.gold != null) setGold(save.gold);
      if (save.ventures) setVentures(save.ventures);
      if (save.prestigeGems != null) setPrestigeGems(save.prestigeGems);
      if (save.totalGems != null) setTotalGems(save.totalGems);
      if (save.lifetimeGold != null) setLifetimeGold(save.lifetimeGold);

      // Offline earnings
      if (save.lastSave && save.ventures) {
        const elapsed = Date.now() - save.lastSave;
        if (elapsed > 5000) {
          let offlineGold = 0;
          const pm = 1 + (save.totalGems || 0) * PRESTIGE_GEM_BONUS;
          save.ventures.forEach((vs, i) => {
            if (vs.hasCompanion && vs.owned > 0) {
              const rev = getRevenue(VENTURES[i], vs.owned, pm);
              const cycles = Math.floor(elapsed / VENTURES[i].baseTime);
              offlineGold += rev * cycles * OFFLINE_EFFICIENCY;
            }
          });
          if (offlineGold > 0) {
            setGold(g => g + offlineGold);
            setLifetimeGold(l => l + offlineGold);
          }
        }
      }
    } catch (e) { /* corrupted save, start fresh */ }
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      try {
        localStorage.setItem(SAVE_KEY, JSON.stringify({
          gold: goldRef.current,
          ventures: venturesRef.current,
          prestigeGems: gemsRef.current,
          totalGems,
          lifetimeGold,
          lastSave: Date.now(),
        }));
      } catch (e) {}
    }, 5000);
    return () => clearInterval(interval);
  }, [totalGems, lifetimeGold]);

  // ═══ GAME LOOP ═══
  const tick = useCallback(() => {
    const now = Date.now();
    const dt = now - lastTick.current;
    lastTick.current = now;

    setVentures(prev => {
      let earned = 0;
      const next = prev.map((vs, i) => {
        if (vs.owned === 0 || (!vs.running && !vs.hasCompanion)) return vs;

        let newProgress = vs.progress + dt;
        const cycleTime = VENTURES[i].baseTime;

        if (newProgress >= cycleTime) {
          const cycles = Math.floor(newProgress / cycleTime);
          earned += getRevenue(VENTURES[i], vs.owned, prestigeMultiplier) * cycles;

          if (vs.hasCompanion) {
            return { ...vs, progress: newProgress % cycleTime, running: true };
          }
          return { ...vs, progress: 0, running: false };
        }
        return { ...vs, progress: newProgress };
      });

      if (earned > 0) {
        setGold(g => g + earned);
        setLifetimeGold(l => l + earned);
      }
      return next;
    });

    animRef.current = requestAnimationFrame(tick);
  }, [prestigeMultiplier]);

  useEffect(() => {
    animRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animRef.current);
  }, [tick]);

  // ═══ ACTIONS ═══
  const handleBuyVenture = (idx) => {
    const v = VENTURES[idx];
    const vs = ventures[idx];
    const qty = buyQty === -1 ? Math.max(1, getMaxBuyable(v.baseCost, vs.owned, gold)) : buyQty;
    const cost = getBulkCost(v.baseCost, vs.owned, qty);
    if (gold < cost) return;
    setGold(g => g - cost);
    setVentures(prev => prev.map((s, i) => i === idx ? { ...s, owned: s.owned + qty } : s));
  };

  const handleStartVenture = (idx) => {
    setVentures(prev => prev.map((s, i) =>
      i === idx && s.owned > 0 && !s.running ? { ...s, running: true, progress: 0 } : s
    ));
  };

  const handleBuyCompanion = (idx) => {
    const cost = COMPANION_COSTS[idx];
    if (gold < cost || ventures[idx].hasCompanion || ventures[idx].owned === 0) return;
    setGold(g => g - cost);
    setVentures(prev => prev.map((s, i) =>
      i === idx ? { ...s, hasCompanion: true, running: true } : s
    ));
  };

  const pendingGems = calcPrestigeGems(lifetimeGold);

  const handlePrestige = () => {
    if (pendingGems <= 0) return;
    setPrestigeGems(g => g + pendingGems);
    setTotalGems(t => t + pendingGems);
    setGold(4);
    setVentures(createInitialState());
    setLifetimeGold(0);
  };

  const handleHardReset = () => {
    if (!confirm("Hard reset everything? This erases ALL progress including Soul Gems.")) return;
    localStorage.removeItem(SAVE_KEY);
    setGold(4);
    setVentures(createInitialState());
    setPrestigeGems(0);
    setTotalGems(0);
    setLifetimeGold(0);
  };

  // ═══ DERIVED VALUES ═══
  const goldPerSecond = VENTURES.reduce((sum, v, i) => {
    const vs = ventures[i];
    if (vs.owned === 0 || (!vs.running && !vs.hasCompanion)) return sum;
    return sum + getRevenue(v, vs.owned, prestigeMultiplier) / (v.baseTime / 1000);
  }, 0);

  // ═══ RENDER ═══
  return (
    <div className="cc">
      <style>{STYLES}</style>

      {/* ── HEADER ── */}
      <div className="hd">
        <div className="hd-top">
          <span className="hd-title">⚔ CASTLE CAPITALIST</span>
          <span className="hd-gems" onClick={() => setTab("prestige")}>
            <SoulGem /> {prestigeGems} ({prestigeMultiplier.toFixed(2)}x)
          </span>
        </div>
        <div className="hd-gold">
          <div className="hd-gold-left">
            <GoldCoin size={18} />
            <span className="hd-amount">{formatNumber(gold)}</span>
            <span className="hd-label">GOLD</span>
          </div>
          <span className="hd-gps"><GoldCoin /> {formatNumber(goldPerSecond)}/sec</span>
        </div>
      </div>

      {/* ── TABS ── */}
      <div className="tabs">
        {[
          { key: "ventures",   label: "⚔ Ventures" },
          { key: "companions", label: "🛡 Companions" },
          { key: "upgrades",   label: "⬆ Upgrades" },
          { key: "prestige",   label: "✦ Ascend" },
        ].map(t => (
          <button key={t.key}
            className={`tab ${tab === t.key ? 'tab-on' : ''}`}
            onClick={() => setTab(t.key)}
          >{t.label}</button>
        ))}
      </div>

      {/* ── BUY QTY ── */}
      {tab === "ventures" && (
        <div className="qty-row">
          {[1, 10, 100, -1].map(q => (
            <button key={q}
              className={`qty ${buyQty === q ? 'qty-on' : ''}`}
              onClick={() => setBuyQty(q)}
            >{q === -1 ? "MAX" : `×${q}`}</button>
          ))}
        </div>
      )}

      {/* ── VENTURES TAB ── */}
      {tab === "ventures" && (
        <div className="vent-list">
          {VENTURES.map((v, i) => {
            const vs = ventures[i];
            const unlocked = vs.owned > 0;
            const qty = buyQty === -1 ? Math.max(1, getMaxBuyable(v.baseCost, vs.owned, gold)) : buyQty;
            const cost = unlocked ? getBulkCost(v.baseCost, vs.owned, qty) : v.unlockCost;
            const canAfford = gold >= cost;
            const pct = unlocked ? Math.min(100, (vs.progress / v.baseTime) * 100) : 0;
            const rev = unlocked ? getRevenue(v, vs.owned, prestigeMultiplier) : 0;
            const perSec = unlocked ? rev / (v.baseTime / 1000) : 0;
            const remaining = unlocked && vs.running ? Math.max(0, v.baseTime - vs.progress) : v.baseTime;

            // Hide far-away ventures
            if (!unlocked && gold < v.unlockCost * 0.05 && i > 2) return null;

            const IconComponent = VENTURE_ICONS[i];

            return (
              <div key={v.id} className={`vrow ${!unlocked ? 'vrow-locked' : ''}`}>
                {/* Badge */}
                <div className="badge"
                  style={{
                    background: `linear-gradient(135deg, ${v.color}33, ${v.colorDark}55)`,
                    borderColor: v.color + '88',
                  }}
                  onClick={() => unlocked && handleStartVenture(i)}
                >
                  <IconComponent color={v.color} />
                  <span className="badge-ct">{vs.owned}</span>
                </div>

                {/* Info */}
                <div className="vmid" onClick={() => unlocked && handleStartVenture(i)}>
                  <div className="vname">
                    {v.name}
                    {vs.hasCompanion && <span className="auto-tag">AUTO</span>}
                  </div>
                  <div className="vrev">
                    <GoldCoin /> {formatNumber(rev)}
                    <span className="vps">{formatNumber(perSec)}/s</span>
                  </div>
                  <div className="bar-out">
                    <div className="bar-in"
                      style={{
                        width: `${pct}%`,
                        background: `linear-gradient(90deg, ${v.colorDark}, ${v.color})`,
                      }}
                    />
                    <span className="bar-time">{formatTime(remaining)}</span>
                  </div>
                  <div className="vms">
                    next: <span className="vms-n">{getNextMilestone(vs.owned)}</span>
                  </div>
                </div>

                {/* Buy */}
                <button className="buy-btn" disabled={!canAfford} onClick={() => handleBuyVenture(i)}>
                  <div className="buy-q">{unlocked ? (buyQty === -1 ? `×${qty}` : `×${buyQty}`) : "UNLOCK"}</div>
                  <div className="buy-c"><GoldCoin />{formatNumber(cost)}</div>
                  <div className="buy-l">{unlocked ? "Buy" : "New"}</div>
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* ── COMPANIONS TAB ── */}
      {tab === "companions" && (
        <div className="comp-list">
          <div className="comp-hdr">🛡 Recruit Dungeon Companions</div>
          <p className="comp-sub">Companions auto-run ventures so you earn gold even while away.</p>
          {VENTURES.map((v, i) => {
            const vs = ventures[i];
            const cost = COMPANION_COSTS[i];
            const canAfford = gold >= cost && !vs.hasCompanion && vs.owned > 0;
            const IconComponent = VENTURE_ICONS[i];

            return (
              <div key={v.id} className="comp-row">
                <div className="comp-info">
                  <div className="comp-icon"
                    style={{
                      background: `linear-gradient(135deg, ${v.color}33, ${v.colorDark}55)`,
                      borderColor: v.color + '66',
                    }}
                  >
                    <IconComponent color={v.color} size={22} />
                  </div>
                  <div>
                    <div className="comp-name">{COMPANION_NAMES[i]}</div>
                    <div className="comp-desc">{COMPANION_DESCS[i]}</div>
                  </div>
                </div>
                {vs.hasCompanion ? (
                  <span className="comp-hired">✦ RECRUITED</span>
                ) : vs.owned === 0 ? (
                  <span className="comp-locked">🔒 Locked</span>
                ) : (
                  <button className="comp-btn" disabled={!canAfford} onClick={() => handleBuyCompanion(i)}>
                    Recruit · <GoldCoin />{formatNumber(cost)}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ── UPGRADES TAB ── */}
      {tab === "upgrades" && (
        <div className="upgrades">
          <div className="up-hdr">⬆ Enchantments & Upgrades</div>
          <p className="up-sub">
            Speed potions, revenue multipliers, and dungeon-wide enchantments will be forged here.
            This is where rewarded ad boosts and premium power-ups would live in the mobile release.
          </p>
        </div>
      )}

      {/* ── PRESTIGE TAB ── */}
      {tab === "prestige" && (
        <div className="prest">
          <div className="prest-title">✦ DUNGEON ASCENSION ✦</div>
          <p className="prest-sub">
            Sacrifice all progress to earn <strong style={{ color: 'var(--gm)' }}>Soul Gems</strong>.
            Each gem permanently enchants ALL gold earnings by {PRESTIGE_GEM_BONUS * 100}%.
          </p>
          <div className="prest-grid">
            <div className="prest-stat">
              <div className="prest-label">Current Gems</div>
              <div className="prest-val" style={{ color: 'var(--gm)' }}><SoulGem size={18} /> {prestigeGems}</div>
            </div>
            <div className="prest-stat">
              <div className="prest-label">Enchantment</div>
              <div className="prest-val">{prestigeMultiplier.toFixed(2)}x</div>
            </div>
            <div className="prest-stat">
              <div className="prest-label">Gems on Ascend</div>
              <div className="prest-val" style={{ color: 'var(--gm)' }}>+{pendingGems}</div>
            </div>
            <div className="prest-stat">
              <div className="prest-label">New Power</div>
              <div className="prest-val">{(1 + (totalGems + pendingGems) * PRESTIGE_GEM_BONUS).toFixed(2)}x</div>
            </div>
          </div>
          <button className="prest-btn" disabled={pendingGems <= 0} onClick={handlePrestige}>
            {pendingGems > 0 ? `⚡ ASCEND (+${pendingGems} Gems)` : "Gather more gold to ascend"}
          </button>
          <p className="prest-hint">
            Next gem at: <GoldCoin />{formatNumber(Math.pow(prestigeGems + totalGems + 1, 2) * PRESTIGE_BASE)} lifetime gold
          </p>
        </div>
      )}

      {/* ── FOOTER ── */}
      <div className="ft">
        <span className="ft-text">Castle Capitalist v0.3</span>
        <button className="ft-reset" onClick={handleHardReset}>Reset</button>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   STYLES — All CSS in one template literal.
   Uses CSS custom properties for easy theming / dark mode.
   ═══════════════════════════════════════════════════════════════ */
const STYLES = `
@import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;900&family=Almendra:wght@400;700&family=Fira+Code:wght@400;600&display=swap');

.cc {
  --bg: #1a1510; --bg2: #241e16;
  --sf: #352b1e; --sf2: #3d3122;
  --bd: #5a4a32; --bd2: #7a6842;
  --gd: #f0c030; --gdl: #ffe082; --gdd: #a07818;
  --gm: #c084fc; --gmd: #7c3aed;
  --gn: #4ade80; --rd: #ef4444;
  --tx: #ede0cc; --txd: #9a8a6e; --txb: #fff8e8;
  font-family: 'Almendra', serif;
  background: var(--bg); color: var(--tx);
  min-height: 100vh; max-width: 480px;
  margin: 0 auto; user-select: none;
  position: relative; overflow-x: hidden;
}
.cc::before {
  content: ''; position: fixed; inset: 0;
  background:
    repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(0,0,0,.03) 3px, rgba(0,0,0,.03) 4px),
    repeating-linear-gradient(90deg, transparent, transparent 3px, rgba(0,0,0,.02) 3px, rgba(0,0,0,.02) 4px);
  pointer-events: none; z-index: 0;
}
.cc * { position: relative; z-index: 1; box-sizing: border-box; }

/* Header */
.hd { background: linear-gradient(180deg,#2a2218,#1e1810); border-bottom: 3px solid var(--bd2); padding: 12px 16px 10px; position: sticky; top: 0; z-index: 20; box-shadow: 0 4px 20px rgba(0,0,0,.5); }
.hd::after { content:''; position:absolute; bottom:-6px; left:0; right:0; height:3px; background:linear-gradient(90deg,transparent,var(--gdd),transparent); }
.hd-top { display:flex; justify-content:space-between; align-items:center; margin-bottom:6px; }
.hd-title { font-family:'Cinzel',serif; font-size:16px; font-weight:900; color:var(--gd); text-shadow:0 2px 4px rgba(0,0,0,.6),0 0 20px rgba(240,192,48,.15); letter-spacing:2px; }
.hd-gems { font-family:'Fira Code',monospace; font-size:11px; color:var(--gm); padding:3px 10px; border-radius:12px; background:rgba(192,132,252,.1); border:1px solid rgba(192,132,252,.25); cursor:pointer; display:flex; align-items:center; gap:4px; }
.hd-gold { display:flex; justify-content:space-between; align-items:baseline; }
.hd-gold-left { display:flex; align-items:baseline; gap:4px; }
.hd-amount { font-family:'Cinzel',serif; font-size:26px; font-weight:900; color:var(--gdl); text-shadow:0 2px 8px rgba(240,192,48,.3); }
.hd-label { font-family:'Fira Code',monospace; font-size:9px; color:var(--gdd); }
.hd-gps { font-family:'Fira Code',monospace; font-size:11px; color:var(--gdd); display:flex; align-items:center; gap:2px; }

/* Tabs */
.tabs { display:flex; background:var(--bg2); border-bottom:2px solid var(--bd); }
.tab { flex:1; padding:10px 0; background:none; border:none; font-family:'Cinzel',serif; font-size:11px; font-weight:700; color:var(--txd); cursor:pointer; border-bottom:2px solid transparent; letter-spacing:.5px; transition:all .2s; }
.tab:hover { color:var(--tx); }
.tab-on { color:var(--gd) !important; border-bottom-color:var(--gd); background:rgba(240,192,48,.04); }

/* Buy Quantity */
.qty-row { display:flex; gap:4px; padding:8px 12px; justify-content:flex-end; background:var(--bg2); }
.qty { padding:4px 14px; font-family:'Fira Code',monospace; font-size:11px; font-weight:600; background:var(--sf); color:var(--txd); border:1px solid var(--bd); border-radius:4px; cursor:pointer; transition:all .15s; }
.qty-on { background:var(--gd) !important; color:var(--bg) !important; border-color:var(--gd) !important; }

/* Venture List */
.vent-list { padding:4px 8px 100px; }
.vrow { display:flex; align-items:center; gap:6px; padding:8px 6px; margin-bottom:4px; background:linear-gradient(135deg,var(--sf),var(--sf2)); border:1px solid var(--bd); border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,.2),inset 0 1px 0 rgba(255,255,255,.03); transition:border-color .2s; }
.vrow:hover { border-color:var(--bd2); }
.vrow-locked { opacity:.4; filter:grayscale(.3); }

/* Icon Badge */
.badge { width:56px; height:56px; border-radius:50%; display:flex; flex-direction:column; align-items:center; justify-content:center; cursor:pointer; flex-shrink:0; border:2px solid; box-shadow:0 2px 8px rgba(0,0,0,.3),inset 0 -2px 4px rgba(0,0,0,.2),inset 0 2px 4px rgba(255,255,255,.1); transition:transform .1s; }
.badge:active { transform:scale(.92); }
.badge-ct { font-family:'Fira Code',monospace; font-size:10px; font-weight:700; color:var(--txb); text-shadow:0 1px 3px rgba(0,0,0,.8); margin-top:1px; }

/* Venture Middle */
.vmid { flex:1; min-width:0; cursor:pointer; }
.vname { font-family:'Cinzel',serif; font-size:12px; font-weight:700; color:var(--txb); margin-bottom:2px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; text-shadow:0 1px 2px rgba(0,0,0,.4); }
.auto-tag { font-family:'Fira Code',monospace; font-size:8px; font-weight:700; color:var(--gn); margin-left:6px; padding:1px 5px; border-radius:3px; background:rgba(74,222,128,.12); }
.vrev { font-family:'Fira Code',monospace; font-size:11px; font-weight:600; color:var(--gdl); margin-bottom:3px; display:flex; align-items:center; gap:2px; }
.vps { font-size:9px; color:var(--txd); margin-left:6px; }

/* Progress Bar */
.bar-out { height:14px; background:#1a1408; border-radius:7px; overflow:hidden; border:1px solid var(--bd); box-shadow:inset 0 2px 4px rgba(0,0,0,.4); margin-bottom:3px; position:relative; }
.bar-in { height:100%; border-radius:6px; position:relative; overflow:hidden; }
.bar-in::after { content:''; position:absolute; inset:0; background:repeating-linear-gradient(-45deg,transparent,transparent 4px,rgba(255,255,255,.08) 4px,rgba(255,255,255,.08) 8px); animation:stripe .8s linear infinite; }
@keyframes stripe { 0%{background-position:0 0} 100%{background-position:16px 0} }
.bar-time { position:absolute; right:6px; top:50%; transform:translateY(-50%); font-family:'Fira Code',monospace; font-size:9px; font-weight:600; color:var(--txb); text-shadow:0 1px 3px rgba(0,0,0,.8); z-index:2; }

/* Milestone */
.vms { font-family:'Fira Code',monospace; font-size:9px; color:var(--txd); }
.vms-n { color:#60a5fa; }

/* Buy Button */
.buy-btn { display:flex; flex-direction:column; align-items:center; justify-content:center; padding:6px 8px; min-width:68px; background:linear-gradient(180deg,var(--sf2),var(--sf)); border:2px solid var(--bd); border-radius:8px; cursor:pointer; font-family:'Fira Code',monospace; transition:all .15s; flex-shrink:0; box-shadow:0 2px 6px rgba(0,0,0,.2),inset 0 1px 0 rgba(255,255,255,.05); }
.buy-btn:hover:not(:disabled) { border-color:var(--gd); box-shadow:0 2px 12px rgba(240,192,48,.2); }
.buy-btn:active:not(:disabled) { transform:scale(.95); }
.buy-btn:disabled { opacity:.3; cursor:default; }
.buy-q { font-size:12px; font-weight:700; color:var(--txb); }
.buy-c { font-size:9px; color:var(--gdd); margin-top:2px; display:flex; align-items:center; gap:1px; }
.buy-l { font-size:8px; color:var(--txd); margin-top:1px; text-transform:uppercase; letter-spacing:.5px; }

/* Companions */
.comp-list { padding:12px 12px 100px; }
.comp-hdr { text-align:center; font-family:'Cinzel',serif; font-size:14px; color:var(--txd); margin-bottom:4px; letter-spacing:1px; }
.comp-sub { text-align:center; font-size:11px; color:var(--txd); margin:0 0 16px; opacity:.7; }
.comp-row { display:flex; justify-content:space-between; align-items:center; padding:10px 12px; margin-bottom:4px; background:var(--sf); border:1px solid var(--bd); border-radius:8px; }
.comp-info { display:flex; align-items:center; gap:10px; }
.comp-icon { width:40px; height:40px; border-radius:50%; display:flex; align-items:center; justify-content:center; border:2px solid; box-shadow:0 2px 6px rgba(0,0,0,.3),inset 0 1px 0 rgba(255,255,255,.1); }
.comp-name { font-family:'Cinzel',serif; font-size:12px; font-weight:700; color:var(--txb); }
.comp-desc { font-size:10px; color:var(--txd); font-style:italic; }
.comp-hired { font-family:'Fira Code',monospace; font-size:11px; color:var(--gn); font-weight:700; }
.comp-locked { font-size:11px; color:var(--txd); }
.comp-btn { padding:7px 16px; font-family:'Cinzel',serif; font-size:11px; font-weight:700; background:linear-gradient(180deg,var(--sf2),var(--sf)); color:var(--gd); border:1px solid var(--bd); border-radius:6px; cursor:pointer; transition:all .15s; display:flex; align-items:center; gap:2px; }
.comp-btn:hover:not(:disabled) { border-color:var(--gd); }
.comp-btn:disabled { opacity:.3; cursor:default; }

/* Upgrades */
.upgrades { padding:12px 12px 100px; }
.up-hdr { text-align:center; font-family:'Cinzel',serif; font-size:14px; color:var(--txd); margin-bottom:16px; letter-spacing:1px; }
.up-sub { text-align:center; color:var(--txd); font-size:12px; line-height:1.7; max-width:320px; margin:0 auto; }

/* Prestige */
.prest { padding:24px 16px 100px; text-align:center; }
.prest-title { font-family:'Cinzel',serif; font-size:20px; font-weight:900; color:var(--gm); letter-spacing:3px; text-shadow:0 2px 12px rgba(192,132,252,.3); margin-bottom:8px; }
.prest-sub { font-size:12px; color:var(--txd); max-width:320px; margin:0 auto 24px; line-height:1.7; }
.prest-grid { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:24px; }
.prest-stat { background:var(--sf); border:1px solid var(--bd); border-radius:10px; padding:14px 10px; }
.prest-label { font-family:'Fira Code',monospace; font-size:9px; color:var(--txd); text-transform:uppercase; letter-spacing:1.5px; margin-bottom:6px; }
.prest-val { font-family:'Cinzel',serif; font-size:18px; font-weight:900; color:var(--txb); display:flex; align-items:center; justify-content:center; gap:4px; }
.prest-btn { padding:14px 36px; font-family:'Cinzel',serif; font-size:15px; font-weight:900; background:linear-gradient(135deg,var(--gm),var(--gmd)); color:#fff; border:2px solid rgba(255,255,255,.15); border-radius:10px; cursor:pointer; letter-spacing:1px; box-shadow:0 4px 20px rgba(124,58,237,.3); transition:all .2s; }
.prest-btn:hover:not(:disabled) { box-shadow:0 4px 30px rgba(124,58,237,.5); transform:translateY(-1px); }
.prest-btn:disabled { opacity:.35; cursor:default; }
.prest-hint { font-family:'Fira Code',monospace; font-size:10px; color:var(--txd); margin-top:16px; display:flex; align-items:center; justify-content:center; gap:3px; }

/* Footer */
.ft { display:flex; justify-content:space-between; align-items:center; padding:8px 16px; border-top:2px solid var(--bd); background:var(--bg2); position:sticky; bottom:0; z-index:20; }
.ft-text { font-family:'Fira Code',monospace; font-size:9px; color:var(--txd); }
.ft-reset { font-family:'Fira Code',monospace; font-size:9px; color:var(--rd); background:none; border:1px solid rgba(239,68,68,.2); border-radius:4px; padding:3px 10px; cursor:pointer; }

/* Scrollbar */
.cc ::-webkit-scrollbar { width:4px; }
.cc ::-webkit-scrollbar-track { background:transparent; }
.cc ::-webkit-scrollbar-thumb { background:var(--bd); border-radius:2px; }
`;

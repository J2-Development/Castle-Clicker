/* ═══════════════════════════════════════════════════════════════
   Castle Capitalist — Custom SVG Icon Library
   Hand-crafted dungeon-themed icons. No emoji. No AI slop.
   ═══════════════════════════════════════════════════════════════ */

export const TorchIcon = ({ color = "#f0c030", size = 28 }) => (
  <svg viewBox="0 0 40 40" width={size} height={size}>
    <rect x="17" y="20" width="6" height="16" rx="1.5" fill="#8B6914" stroke="#5a4510" strokeWidth="0.8"/>
    <rect x="18.5" y="21" width="3" height="14" rx="1" fill="#a07820" opacity="0.4"/>
    <ellipse cx="20" cy="19" rx="5" ry="4" fill={color} opacity="0.25"/>
    <path d="M20 6 C14 12, 14 16, 17 19 C18 20, 22 20, 23 19 C26 16, 26 12, 20 6Z" fill={color}/>
    <path d="M20 9 C17 13, 17 15, 18.5 17.5 C19 18.5, 21 18.5, 21.5 17.5 C23 15, 23 13, 20 9Z" fill="#fff3c4" opacity="0.7"/>
    <path d="M20 12 C18.5 14, 19 16, 20 17 C21 16, 21.5 14, 20 12Z" fill="#fff" opacity="0.5"/>
  </svg>
);

export const DaggerIcon = ({ color = "#6dba4a", size = 28 }) => (
  <svg viewBox="0 0 40 40" width={size} height={size}>
    <path d="M12 28 L18 22 L16 20 Z" fill="#8B6914" stroke="#5a4510" strokeWidth="0.6"/>
    <rect x="17.5" y="19.5" width="5" height="2.5" rx="0.5" fill="#a0a0a0" stroke="#666" strokeWidth="0.5" transform="rotate(-45 20 20.5)"/>
    <path d="M21 19 L32 8" stroke="#ccc" strokeWidth="2.5" strokeLinecap="round"/>
    <path d="M21 19 L32 8" stroke="#e8e8e8" strokeWidth="1.2" strokeLinecap="round"/>
    <path d="M31 9 L33 7" stroke={color} strokeWidth="2" strokeLinecap="round"/>
    <circle cx="32.5" cy="7.5" r="2" fill={color} opacity="0.3"/>
  </svg>
);

export const MushroomIcon = ({ color = "#c74f8e", size = 28 }) => (
  <svg viewBox="0 0 40 40" width={size} height={size}>
    <rect x="17" y="22" width="6" height="12" rx="2" fill="#e8dcc8" stroke="#bba888" strokeWidth="0.6"/>
    <rect x="18.5" y="24" width="3" height="8" rx="1" fill="#d4c4a8" opacity="0.5"/>
    <ellipse cx="20" cy="22" rx="13" ry="10" fill={color}/>
    <ellipse cx="20" cy="20" rx="11" ry="7" fill={color} opacity="0.3"/>
    <circle cx="15" cy="18" r="2.5" fill="rgba(255,255,255,0.25)"/>
    <circle cx="23" cy="16" r="1.8" fill="rgba(255,255,255,0.2)"/>
    <circle cx="19" cy="14" r="1.2" fill="rgba(255,255,255,0.2)"/>
    <circle cx="26" cy="20" r="1.5" fill="rgba(255,255,255,0.15)"/>
  </svg>
);

export const SkullIcon = ({ color = "#8bb8d0", size = 28 }) => (
  <svg viewBox="0 0 40 40" width={size} height={size}>
    <ellipse cx="20" cy="17" rx="11" ry="12" fill="#e8e0d0"/>
    <ellipse cx="20" cy="17" rx="11" ry="12" fill={color} opacity="0.2"/>
    <ellipse cx="20" cy="16" rx="9" ry="10" fill="#f0eade" opacity="0.3"/>
    <ellipse cx="15" cy="16" rx="3.5" ry="4" fill="#1a1510"/>
    <ellipse cx="25" cy="16" rx="3.5" ry="4" fill="#1a1510"/>
    <ellipse cx="15" cy="15.5" rx="1.5" ry="2" fill={color} opacity="0.6"/>
    <ellipse cx="25" cy="15.5" rx="1.5" ry="2" fill={color} opacity="0.6"/>
    <path d="M17 24 L17 28" stroke="#1a1510" strokeWidth="1.5" strokeLinecap="round"/>
    <path d="M20 25 L20 29" stroke="#1a1510" strokeWidth="1.5" strokeLinecap="round"/>
    <path d="M23 24 L23 28" stroke="#1a1510" strokeWidth="1.5" strokeLinecap="round"/>
    <ellipse cx="20" cy="21" rx="2" ry="1.5" fill="#2a2018"/>
  </svg>
);

export const GearIcon = ({ color = "#b0885a", size = 28 }) => (
  <svg viewBox="0 0 40 40" width={size} height={size}>
    <g transform="translate(20,20)">
      {[0,45,90,135,180,225,270,315].map((a, i) => (
        <rect key={i} x="-2.8" y="-14" width="5.6" height="6" rx="1.2" fill={color} transform={`rotate(${a})`} stroke="#5a4510" strokeWidth="0.4"/>
      ))}
      <circle r="9" fill={color} stroke="#5a4510" strokeWidth="0.6"/>
      <circle r="4" fill="#1a1510"/>
      <circle r="2.5" fill={color} opacity="0.3"/>
    </g>
  </svg>
);

export const ChestIcon = ({ color = "#d4a843", size = 28 }) => (
  <svg viewBox="0 0 40 40" width={size} height={size}>
    <rect x="7" y="18" width="26" height="14" rx="2" fill="#8B6914" stroke="#5a4510" strokeWidth="0.8"/>
    <rect x="8" y="19" width="24" height="5" fill="#a07820" opacity="0.3"/>
    <path d="M7 18 L7 14 Q7 10, 11 10 L29 10 Q33 10, 33 14 L33 18 Z" fill={color} stroke="#5a4510" strokeWidth="0.8"/>
    <path d="M9 17 L9 14 Q9 12, 12 12 L28 12 Q31 12, 31 14 L31 17 Z" fill="#e8c060" opacity="0.3"/>
    <rect x="17" y="15" width="6" height="8" rx="1" fill="#5a4510"/>
    <circle cx="20" cy="20" r="2" fill={color}/>
    <circle cx="20" cy="20" r="1" fill="#fff" opacity="0.3"/>
  </svg>
);

export const DragonIcon = ({ color = "#d45050", size = 28 }) => (
  <svg viewBox="0 0 40 40" width={size} height={size}>
    <ellipse cx="20" cy="22" rx="10" ry="9" fill={color}/>
    <ellipse cx="20" cy="21" rx="8" ry="7" fill="#e06060" opacity="0.3"/>
    <path d="M10 18 L6 8 L14 14 Z" fill={color} stroke="#8a2020" strokeWidth="0.5"/>
    <path d="M30 18 L34 8 L26 14 Z" fill={color} stroke="#8a2020" strokeWidth="0.5"/>
    <ellipse cx="15" cy="19" rx="3" ry="3.5" fill="#1a1510"/>
    <ellipse cx="25" cy="19" rx="3" ry="3.5" fill="#1a1510"/>
    <ellipse cx="15.8" cy="18.5" rx="1.2" ry="2" fill="#f0c030"/>
    <ellipse cx="25.8" cy="18.5" rx="1.2" ry="2" fill="#f0c030"/>
    <ellipse cx="18" cy="27" rx="1" ry="0.6" fill="#1a1510"/>
    <ellipse cx="22" cy="27" rx="1" ry="0.6" fill="#1a1510"/>
    <path d="M16 30 L18 32 L20 30 L22 32 L24 30" stroke={color} strokeWidth="1.2" fill="none" opacity="0.6"/>
  </svg>
);

export const CrownIcon = ({ color = "#a855f7", size = 28 }) => (
  <svg viewBox="0 0 40 40" width={size} height={size}>
    <path d="M8 28 L8 16 L14 22 L20 12 L26 22 L32 16 L32 28 Z" fill={color} stroke="#6a2aaa" strokeWidth="0.8"/>
    <path d="M10 27 L10 18 L14.5 22.5 L20 14 L25.5 22.5 L30 18 L30 27 Z" fill="#c084fc" opacity="0.25"/>
    <rect x="8" y="27" width="24" height="4" rx="1" fill={color} stroke="#6a2aaa" strokeWidth="0.8"/>
    <circle cx="14" cy="16" r="2" fill="#f0c030"/>
    <circle cx="20" cy="12" r="2.5" fill="#f0c030"/>
    <circle cx="26" cy="16" r="2" fill="#f0c030"/>
    <circle cx="14" cy="16" r="0.8" fill="#fff" opacity="0.5"/>
    <circle cx="20" cy="12" r="1" fill="#fff" opacity="0.5"/>
    <circle cx="26" cy="16" r="0.8" fill="#fff" opacity="0.5"/>
  </svg>
);

export const VolcanoIcon = ({ color = "#ef4444", size = 28 }) => (
  <svg viewBox="0 0 40 40" width={size} height={size}>
    <path d="M4 36 L15 12 L25 12 L36 36 Z" fill="#5a3a1a" stroke="#3a2510" strokeWidth="0.6"/>
    <path d="M8 36 L16 14 L24 14 L32 36 Z" fill="#6a4a2a" opacity="0.4"/>
    <ellipse cx="20" cy="12" rx="6" ry="3" fill="#3a2510"/>
    <path d="M16 12 Q18 4, 20 2 Q22 4, 24 12" fill={color} opacity="0.8"/>
    <path d="M17.5 12 Q19 6, 20 4 Q21 6, 22.5 12" fill="#f0c030" opacity="0.6"/>
    <circle cx="18" cy="7" r="1.5" fill={color} opacity="0.5"/>
    <circle cx="22" cy="5" r="1" fill="#f0c030" opacity="0.5"/>
    <circle cx="20" cy="3" r="1.5" fill="#fff" opacity="0.2"/>
    <path d="M14 24 Q16 22, 18 24 Q20 22, 22 24 Q24 22, 26 24" stroke={color} strokeWidth="1" fill="none" opacity="0.4"/>
  </svg>
);

export const VoidIcon = ({ color = "#06b6d4", size = 28 }) => (
  <svg viewBox="0 0 40 40" width={size} height={size}>
    <circle cx="20" cy="20" r="13" fill="#0a1a2a" stroke={color} strokeWidth="1"/>
    <circle cx="20" cy="20" r="10" fill="none" stroke={color} strokeWidth="0.6" opacity="0.5"/>
    <circle cx="20" cy="20" r="7" fill="none" stroke={color} strokeWidth="0.4" opacity="0.3"/>
    <circle cx="20" cy="20" r="4" fill={color} opacity="0.3"/>
    <circle cx="20" cy="20" r="2" fill={color} opacity="0.5"/>
    <circle cx="20" cy="20" r="0.8" fill="#fff" opacity="0.8"/>
    {[0,60,120,180,240,300].map((a, i) => (
      <circle key={i} cx={20 + 11 * Math.cos(a * Math.PI / 180)} cy={20 + 11 * Math.sin(a * Math.PI / 180)} r="1.2" fill={color} opacity="0.4"/>
    ))}
  </svg>
);

export const GoldCoin = ({ size = 14 }) => (
  <svg viewBox="0 0 20 20" width={size} height={size} style={{verticalAlign:'middle', marginRight:2, display:'inline-block'}}>
    <circle cx="10" cy="10" r="8" fill="#f0c030" stroke="#a07818" strokeWidth="1.2"/>
    <circle cx="10" cy="10" r="5.5" fill="none" stroke="#a07818" strokeWidth="0.6" opacity="0.4"/>
    <text x="10" y="14" textAnchor="middle" fill="#8a6010" fontSize="10" fontWeight="bold" fontFamily="serif">G</text>
  </svg>
);

export const SoulGem = ({ size = 14 }) => (
  <svg viewBox="0 0 20 20" width={size} height={size} style={{verticalAlign:'middle', marginRight:2, display:'inline-block'}}>
    <path d="M6 8 L10 3 L14 8 L10 17 Z" fill="#c084fc" stroke="#7c3aed" strokeWidth="0.8"/>
    <path d="M6 8 L10 3 L10 17 Z" fill="#d4a0ff" opacity="0.3"/>
    <path d="M8 7 L10 4 L12 7 L10 8 Z" fill="#fff" opacity="0.2"/>
  </svg>
);

// Ordered array matching venture indices
export const VENTURE_ICONS = [
  TorchIcon, DaggerIcon, MushroomIcon, SkullIcon, GearIcon,
  ChestIcon, DragonIcon, CrownIcon, VolcanoIcon, VoidIcon,
];

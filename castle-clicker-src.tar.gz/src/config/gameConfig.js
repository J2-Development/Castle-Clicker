/* ═══════════════════════════════════════════════════════════════
   Castle Capitalist — Game Configuration
   All tuning knobs in one place. Tweak these to balance the game.
   ═══════════════════════════════════════════════════════════════ */

export const VENTURES = [
  { id:0, name:"Torch Scavenging",     color:"#e8a023", colorDark:"#a06810", baseCost:4,           baseRevenue:1,            baseTime:600,    unlockCost:0 },
  { id:1, name:"Goblin Pickpocketing",  color:"#6dba4a", colorDark:"#3d7a22", baseCost:60,          baseRevenue:60,           baseTime:3000,   unlockCost:60 },
  { id:2, name:"Mushroom Foraging",     color:"#c74f8e", colorDark:"#8a2a5e", baseCost:720,         baseRevenue:540,          baseTime:6000,   unlockCost:720 },
  { id:3, name:"Skeleton Looting",      color:"#8bb8d0", colorDark:"#4a7a94", baseCost:8640,        baseRevenue:4320,         baseTime:12000,  unlockCost:8640 },
  { id:4, name:"Trap Disarming",        color:"#b0885a", colorDark:"#7a5a30", baseCost:103680,      baseRevenue:51840,        baseTime:24000,  unlockCost:103680 },
  { id:5, name:"Mimic Hunting",         color:"#d4a843", colorDark:"#9a7420", baseCost:1244160,     baseRevenue:622080,       baseTime:48000,  unlockCost:1244160 },
  { id:6, name:"Dragon Hoard Raid",     color:"#d45050", colorDark:"#8a2020", baseCost:14929920,    baseRevenue:7464960,      baseTime:96000,  unlockCost:14929920 },
  { id:7, name:"Lich Vault Breach",     color:"#a855f7", colorDark:"#6a2aaa", baseCost:179159040,   baseRevenue:89579520,     baseTime:192000, unlockCost:179159040 },
  { id:8, name:"Demon Gate Siege",      color:"#ef4444", colorDark:"#991b1b", baseCost:2149908480,  baseRevenue:1074954240,   baseTime:384000, unlockCost:2149908480 },
  { id:9, name:"Elder God Pact",        color:"#06b6d4", colorDark:"#0e7490", baseCost:25798901760, baseRevenue:12899450880,  baseTime:768000, unlockCost:25798901760 },
];

// Revenue doubles at each of these ownership counts
export const MILESTONES = [
  25, 50, 100, 200, 300, 400, 500, 600, 700, 800,
  900, 1000, 1100, 1200, 1300, 1400, 1500, 1600, 1700, 1800,
  1900, 2000, 2250, 2500, 2750, 3000, 3500, 4000, 4500, 5000,
];

// Cost to recruit each companion (auto-runner)
export const COMPANION_COSTS = [
  1000, 15000, 100000, 500000, 10_000_000,
  100_000_000, 1_000_000_000, 100_000_000_000,
  5_000_000_000_000, 500_000_000_000_000,
];

export const COMPANION_NAMES = [
  "Squire Finn",
  "Rogue Nyx",
  "Fungi Sage",
  "Bone Collector",
  "Trapmaster Vex",
  "Chest Warden",
  "Dragonkeeper Ash",
  "Lich Servant Morrn",
  "Demon Binder Kael",
  "Void Priest Zara",
];

export const COMPANION_DESCS = [
  "A loyal torchbearer",
  "Nimble-fingered thief",
  "Ancient spore whisperer",
  "Harvests the undead",
  "Defuses any mechanism",
  "Guards mimics & loot",
  "Speaks draconic tongue",
  "Bound beyond death",
  "Commands hellfire",
  "Channels the abyss",
];

// Prestige config
export const PRESTIGE_BASE = 1e10;       // lifetime gold needed for first gem
export const PRESTIGE_GEM_BONUS = 0.02;  // +2% per gem

// Cost scaling
export const COST_EXPONENT = 1.07;       // each unit costs 7% more

// Offline earnings multiplier (1.0 = full, 0.5 = half)
export const OFFLINE_EFFICIENCY = 0.5;

// Save key for localStorage / AsyncStorage
export const SAVE_KEY = "castle_capitalist_v3";

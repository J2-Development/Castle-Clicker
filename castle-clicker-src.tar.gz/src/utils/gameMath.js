/* ═══════════════════════════════════════════════════════════════
   Castle Capitalist — Game Math Utilities
   Pure functions for all game calculations.
   ═══════════════════════════════════════════════════════════════ */

import { MILESTONES, COST_EXPONENT, PRESTIGE_BASE } from '../config/gameConfig';

/**
 * Get the cumulative milestone multiplier for a given ownership count.
 * Revenue doubles at each milestone threshold.
 */
export const getMilestoneMultiplier = (count) => {
  let mult = 1;
  for (const ms of MILESTONES) {
    if (count >= ms) mult *= 2;
    else break;
  }
  return mult;
};

/**
 * Cost of the Nth unit (0-indexed from current owned count).
 */
export const getUnitCost = (baseCost, owned) => {
  return Math.floor(baseCost * Math.pow(COST_EXPONENT, owned));
};

/**
 * Total cost to buy `qty` units starting from `owned`.
 */
export const getBulkCost = (baseCost, owned, qty) => {
  let total = 0;
  for (let i = 0; i < qty; i++) {
    total += getUnitCost(baseCost, owned + i);
  }
  return total;
};

/**
 * Revenue per cycle for a venture at given count and prestige multiplier.
 */
export const getRevenue = (venture, count, prestigeMultiplier) => {
  return venture.baseRevenue * count * getMilestoneMultiplier(count) * prestigeMultiplier;
};

/**
 * Maximum units buyable with current gold.
 */
export const getMaxBuyable = (baseCost, owned, gold) => {
  let max = 0;
  let cost = 0;
  let o = owned;
  while (cost + getUnitCost(baseCost, o) <= gold) {
    cost += getUnitCost(baseCost, o);
    o++;
    max++;
  }
  return max;
};

/**
 * Calculate prestige gems earned from lifetime gold.
 */
export const calcPrestigeGems = (lifetimeGold) => {
  return Math.max(0, Math.floor(Math.sqrt(lifetimeGold / PRESTIGE_BASE)));
};

/**
 * Find the next milestone threshold above current count.
 */
export const getNextMilestone = (count) => {
  return MILESTONES.find(m => m > count) || "MAX";
};

/**
 * Format large numbers with suffixes (K, M, B, T, Qa, etc.)
 */
export const formatNumber = (n) => {
  if (n < 0) return "-" + formatNumber(-n);
  if (n < 1000) return Math.floor(n).toString();

  const SUFFIXES = [
    "", "K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No",
    "Dc", "UDc", "DDc", "TDc", "QaDc", "QiDc", "SxDc", "SpDc", "OcDc", "NoDc",
    "Vg", "UVg", "DVg", "TVg", "QaVg", "QiVg", "SxVg", "SpVg", "OcVg", "NoVg", "Tg",
  ];

  let tier = 0;
  let scaled = n;
  while (scaled >= 1000 && tier < SUFFIXES.length - 1) {
    scaled /= 1000;
    tier++;
  }

  const decimals = scaled < 10 ? 2 : scaled < 100 ? 1 : 0;
  return scaled.toFixed(decimals) + " " + SUFFIXES[tier];
};

/**
 * Format milliseconds as MM:SS or H:MM:SS
 */
export const formatTime = (ms) => {
  const totalSeconds = ms / 1000;
  if (totalSeconds < 1) return "00:00";

  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = Math.floor(totalSeconds % 60);

  if (hours > 0) {
    return `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
};

# 🏰 Castle Capitalist

An idle/incremental dungeon game inspired by Adventure Capitalist. Built with React, designed to port to React Native + Expo for iOS/Android.

## Game Overview

Run dungeon ventures to earn gold. Buy more ventures, hire companions to automate them, hit milestones for multiplier boosts, and prestige (ascend) for permanent bonuses. Classic idle loop with dungeon theming.

### Core Systems
- **10 Dungeon Ventures** — Torch Scavenging → Elder God Pact
- **Exponential Scaling** — 1.07x cost per unit, milestone doublings at 25/50/100/200+
- **Companions** — Auto-run ventures (equivalent to "managers" in AdCap)
- **Prestige (Ascension)** — Reset for Soul Gems, each giving +2% permanent gold boost
- **Offline Earnings** — Managed ventures earn at 50% efficiency while away
- **Auto-save** — Every 5 seconds to localStorage

### Monetization Hooks (planned)
- Rewarded ads for 2x gold boost
- Skip potions (jump N floors)
- Watch ad to double offline earnings
- Cosmetic skins (heroes, dungeons)
- Battle pass / seasonal dungeons

## Project Structure

```
src/
├── components/
│   ├── CastleCapitalist.jsx   # Main game component
│   └── Icons.jsx              # Custom SVG icon library
├── config/
│   └── gameConfig.js          # All game tuning data
└── utils/
    └── gameMath.js            # Pure math/formatting functions
```

## Architecture Notes

The code is structured for a clean port to React Native + Expo:

| Web (current)          | React Native (planned)          |
|------------------------|---------------------------------|
| `localStorage`         | `AsyncStorage` / `expo-secure-store` |
| `requestAnimationFrame`| Same, or `setInterval` for battery |
| CSS classes            | StyleSheet / Tailwind NativeWind |
| SVG components         | `react-native-svg`             |
| Progress bar CSS       | `Animated` / `react-native-reanimated` |
| Ad hooks               | `expo-ads-admob`               |

## Getting Started (Web Prototype)

The main component is `CastleCapitalist.jsx`. It's a self-contained React component that can be dropped into any React project or rendered in the Claude artifact viewer.

For local development:
```bash
npx create-react-app castle-capitalist
# Copy src/ files into the project
# Import CastleCapitalist in App.js
```

## Tech Stack
- **React** (hooks, functional components)
- **Custom SVG icons** (no emoji, no external assets)
- **CSS-in-JS** (template literal, CSS custom properties)
- **Fonts**: Cinzel (headers), Almendra (body), Fira Code (numbers)

## Game Balance

All tuning constants live in `src/config/gameConfig.js`:
- `COST_EXPONENT` — How fast venture prices scale (default: 1.07)
- `MILESTONES` — Ownership counts that double revenue
- `PRESTIGE_BASE` — Lifetime gold needed for first prestige gem
- `PRESTIGE_GEM_BONUS` — Percentage boost per gem (default: 0.02 = 2%)
- `OFFLINE_EFFICIENCY` — Fraction of earnings while offline (default: 0.5)

## License

Proprietary — J2 Development
